package com.generics;

public class Container<T> {
	
	T value;
	public void setItem(T x) {
		value=x;
	
	}
	public T getItem() {
		// TODO Auto-generated method stub
		return value;
	}

}
